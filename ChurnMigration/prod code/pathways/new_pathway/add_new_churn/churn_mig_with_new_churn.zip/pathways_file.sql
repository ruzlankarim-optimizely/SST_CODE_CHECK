Line of Business (LOB) = ‘ Licenses ’ > Line of Business (LOB) = ‘ Cloud ’ & Solution Li = Orch or Monetize 
- Product = ‘ Everweb ’ > Prod Solution Li = Orch or Monetize 
- Product = ‘ Ektron ’ > Product = ‘ Content Management System (CMS) ’ 
- Product = ’ Find ’ > Prod Solution Li = Orch  or Monetize 
- Product = ’ Visitor Intelligence ’ > Product = ‘ Data Platform (ODP) ’


lob 